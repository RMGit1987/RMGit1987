package com.testassignment1;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.testassignment.pages.BaseClass;
import com.testassignment.pages.HomePageActions;
import com.testassignment.pages.LoginFacebook;
import com.testassignment.utility.Helper;


public class FacebookTestWorkflow extends BaseClass{
	
	boolean blnContinue = true;
	
	@Test
	public void loginFb_WritePost() {
		
		try {
			//custom test to report in extent report html file
			logger=report.createTest("Login to Facebook and write a post.");
			
			//initialize the elements of facebook login page
			LoginFacebook loginPage=PageFactory.initElements(driver, LoginFacebook.class);
			
			//do login on facebook page 
			if(loginPage.loginToFbHomePage(excel.getStringData("FbLogin", 0, 0), excel.getStringData("FbLogin", 0, 1))) {
				logger.pass("Logged in succesfully to Facebook web site.");
			}else {
				logger.fail("Logged in failure to Facebook web site.");
				blnContinue=false;
			}
			
			//initialize the elements of the facebook home page
			HomePageActions userActivity = PageFactory.initElements(driver, HomePageActions.class);
			
			//get runtime data timestamp and use it for post message
			String strDynamicMsg = Helper.getCurrentDateTime();
			
			//write post to the facebook page
			if(userActivity.writeFBPost(excel.getStringData("FbLogin", 0, 2) + strDynamicMsg)) {
				logger.pass("Post written succesfully on site");
			}else {
				logger.fail("Post not written succesfully on site.");
				blnContinue=false;
			}
				
			//verify post on facebook page
			if(userActivity.verifyPostExistence(excel.getStringData("FbLogin", 0, 2) + strDynamicMsg)) {
				logger.pass("Post verified succesfully on site.");
			}else {
				logger.fail("Post not verified succesfully on site.");
				blnContinue=false;
			}
			
		} catch (Exception e) {
			logger.fail("Runtime exception occured - "+e.getMessage());	
			blnContinue=false;
		}
		
		//check and assert PASS/FAIL status to the entire method based on the global boolean variable 
		assertEquals(true, blnContinue);
	}
	
}

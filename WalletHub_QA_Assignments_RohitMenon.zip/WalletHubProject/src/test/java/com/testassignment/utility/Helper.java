package com.testassignment.utility;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

public class Helper{

	// screenshots , alerts , frames, windows , syncissues, javascript executor
	
	public static String capturescreenshot(WebDriver driver) {
		
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		String screenshotpath=System.getProperty("user.dir")+"/Screenshots/"+ getCurrentDateTime() +".png";	
		
		try {
			FileHandler.copy(src, new File(screenshotpath));
		} catch (IOException e) {
			Reporter.log("Unable to capture screenshot "+e.getMessage(), true);
		}	
		
		Reporter.log("Screenshot Captured", true);
		
		return screenshotpath;
	}
	
	public static String getCurrentDateTime() {
		
		DateFormat customformat=new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		Date currentDate = new Date();
		
		return customformat.format(currentDate);
	}

	public static boolean waitForElementToBeDisplayed(WebElement element, WebDriver driver, int specifiedTimeout) {
		WebDriverWait wait = new WebDriverWait(driver, specifiedTimeout);
		boolean iRet;
		try {
			ExpectedCondition<Boolean> elementIsDisplayed = arg0 -> element.isDisplayed();
			wait.until(elementIsDisplayed);
			
			//Reporter.log("WebElement - " + element.getText() + " displayed succesfully.",true);
			iRet=true;
		} catch (Exception e) {
		
			Reporter.log("required object verification is not identified in time "+e.getMessage(), true);
			iRet=false;
		}
		
		return iRet;
	}
	
	public static List<WebElement> waitAndReturnElementsListBasedOnCSSSelector(String customCssSelector, WebDriver driver, int specifiedTimeout) {
		WebDriverWait wait = new WebDriverWait(driver, specifiedTimeout);
		List<WebElement> elemCollection = Collections.emptyList();
		try {
			//"#reviews-section > modal-dialog > div > div > write-review > review-star > div > svg"
			elemCollection = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector(customCssSelector)));

		} catch (Exception e) {
		
			Reporter.log("required object collection not identified !! "+e.getMessage(), true);

		}
		
		return elemCollection;
	}
	
	public static boolean verifyCollectionListSize(List<WebElement> listVerify, int totalSize) {
		
		boolean iRet = true;
		if((listVerify.size() == totalSize)) {
			//Reporter.log("required object collection size validated as expected",true);
		}else {
			iRet = false;
			Reporter.log("required object collection size validated failed", true);
		}
		
		return iRet;
	}

	public static boolean verifyElementText(WebElement element, WebDriver driver, String textToVerify) {
		
		int specifiedTimeout = 5;
		WebDriverWait wait = new WebDriverWait(driver, specifiedTimeout);
		boolean iRet =  true;
		try {
			wait.until(ExpectedConditions.textToBePresentInElement(element,textToVerify));
			
			Reporter.log("Web Element text  " + textToVerify + " verified succesfully.", true);
		} catch (Exception e) {
			
			try {
				Reporter.log("Web Element text existence of "+ textToVerify + " failed using text attribute, trying for value attribute ... ", true);
				wait.until(ExpectedConditions.textToBePresentInElementValue(element, textToVerify));
				Reporter.log("Web Element text  " + textToVerify + " verified succesfully using value attribute within TIMEOUT of - " + specifiedTimeout, true);
				
			}catch(Exception e2){
				
				Reporter.log("Web Element text  " + textToVerify + " failed to verify both with text and value attributes within TIMEOUT of - " + specifiedTimeout + " . Error : "+ e2.getMessage(), true);
				iRet=false;
			}
		}
		
		return iRet;
	}
	
	public static boolean clickDivElementbyText(String elementText, WebDriver driver) {
		
		int specifiedTimeout = 5;
		WebElement elem;
		WebDriverWait wait = new WebDriverWait(driver, specifiedTimeout);
		boolean iRet;
		
		try {
			
			elem = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'"+elementText+"')]")));
			elem.click();
			iRet=true;
			Reporter.log("Clicked Web Element having text  " + elementText, true);
			
		} catch (Exception e) {
			iRet=false;
			Reporter.log("Click failed for Web Element having text  " + elementText + " - runtime error : "+ e.getMessage(), true);
		}
		
		
		
		return iRet;
	}
	
	public static WebElement waitAndReturnElementBasedOnCSSSelector(String customCssSelector, WebDriver driver, int specifiedTimeout) {
		WebDriverWait wait = new WebDriverWait(driver, specifiedTimeout);
		WebElement elem = null;
		
		try {
			//"#reviews-section > modal-dialog > div > div > write-review > review-star > div > svg"
			elem  = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(customCssSelector)));

		} catch (Exception e) {
		
			Reporter.log("required object not identified !! "+e.getMessage(), true);

		}
		
		return elem;
	}
	
}



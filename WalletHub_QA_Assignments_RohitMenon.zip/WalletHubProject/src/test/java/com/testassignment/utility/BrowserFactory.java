package com.testassignment.utility;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Reporter;

public class BrowserFactory {
	
	public static WebDriver startApplication(WebDriver driver,String browserName, String appUrl) {
		
		if(browserName.equals("Chrome")){
			System.setProperty("webdriver.chrome.driver","./Drivers/chromedriver.exe");
			//Create a map to store  preferences 
			Map<String, Object> prefs = new HashMap<String, Object>();

			//add key and value to map as follow to switch off browser notification
			//Pass the argument 1 to allow and 2 to block
			prefs.put("profile.default_content_setting_values.notifications", 2);

			//Create an instance of ChromeOptions 
			ChromeOptions options = new ChromeOptions();

			// set ExperimentalOption - prefs 
			options.setExperimentalOption("prefs", prefs);
			driver=new ChromeDriver(options);
			
		}else if(browserName.equals("Firefox")){
			System.setProperty("webdriver.gecko.driver","./Drivers/geckodriver.exe");
			driver=new FirefoxDriver();
			
		}else if(browserName.equals("IE")){
			System.setProperty("webdriver.ie.driver","./Drivers/IEDriverServer.exe");
			driver=new InternetExplorerDriver();
			
		}else {
			Reporter.log("We do not support this browser", true);
		}
		
		
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(appUrl);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		return driver;
		
		
	}

	public static void quitBrowser(WebDriver driver) {
		driver.quit();
	}
	
	public static void loadCustomUrl(WebDriver driver, String custUrl) {
		driver.get(custUrl);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

}

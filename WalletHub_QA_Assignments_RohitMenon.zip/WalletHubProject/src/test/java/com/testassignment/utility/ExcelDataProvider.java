package com.testassignment.utility;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.*;
import org.testng.Reporter;

public class ExcelDataProvider {
	
	XSSFWorkbook wb;
	
	public ExcelDataProvider() {
		
		File src=new File("./TestData/testData.xlsx");

		try {
			FileInputStream fis=new FileInputStream(src);
			wb=new XSSFWorkbook(fis);
			
		} catch (Exception e) {
			Reporter.log("Unable to read Excel file"+e.getMessage(), true);
		}
	}
	
	public String getStringData(String excelsheetName,int excelrow,int excelcolumn) {
		return wb.getSheet(excelsheetName).getRow(excelrow).getCell(excelcolumn).getStringCellValue();
	}
	
	//method overloading 
	public String getStringData(int excelSheetIndex,int excelrow,int excelcolumn) {
		return wb.getSheetAt(excelSheetIndex).getRow(excelrow).getCell(excelcolumn).getStringCellValue();
	}
	
	public double getNumericData(String excelsheetName,int excelrow,int excelcolumn) {
		return wb.getSheet(excelsheetName).getRow(excelrow).getCell(excelcolumn).getNumericCellValue();
	}
	

}

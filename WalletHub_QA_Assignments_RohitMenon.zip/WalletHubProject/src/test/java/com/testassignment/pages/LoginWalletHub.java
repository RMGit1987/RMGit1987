package com.testassignment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;

public class LoginWalletHub {
	
	WebDriver driver;
	
	public LoginWalletHub(WebDriver pdriver){
		this.driver=pdriver;
	}
	
	@FindBy(xpath="//li/a[text()='Login']") WebElement loginTab;
	@FindBy(xpath="//input[@type='text' and @name='em']") WebElement inputEmail;
	@FindBy(xpath="//input[@type='password' and @name='pw1']") WebElement inputPwd;
	@FindBy(xpath="//button[@class='btn blue touch-element-cl']") WebElement loginBtn;
	
	
	public String authenticateWithCreds(String userEmail, String userPwd) {
		
		Reporter.log("Login to WALLETHUB Account", true);
		String strSubString = new String();
		String strFormattedSubString = new String();
		
		try {
			//Thread.sleep(2000);
			
			if (loginTab.isSelected() == false) {
				loginTab.click();
				Reporter.log("Login tab selected.", true);
			}else{
				Reporter.log("Login tab is already selected.", true);
			} // to mention the login tab if clicked already or not
			
			
			inputEmail.click();
			inputEmail.clear();
			inputEmail.sendKeys(userEmail);
			inputPwd.click();
			inputPwd.clear();
			inputPwd.sendKeys(userPwd);
			
			// to form the expected user name from input parameters of function and validate further
			strSubString = userEmail.substring(0, userEmail.indexOf('@')).toLowerCase(); // GET PART of string to form user name	
			strFormattedSubString = strSubString.replaceAll("[^a-zA-Z0-9]","_");
			
			Reporter.log("logged in user account would be - "+ strFormattedSubString , true);
			// Submit with set values		
			loginBtn.submit(); // submit the login form
					
		} catch (Exception e) {
			Reporter.log("loginToWalletHub Account failure - "+e.getMessage(), true);
		}
		
		return strFormattedSubString;	
	
	}
	
	public boolean verifyLoginSuccess(String loggedinAccText) {
		
		Reporter.log("Verifying login on WallletHub Site", true);
		
		boolean iRet = true;
		////span[contains(normalize-space(),'rohit_menon87_qa')]
		//"//h2[.='@" + loggedinAccText + "']"
		try {
			if(this.driver.findElement(By.xpath("//span[contains(normalize-space(),'" + loggedinAccText + "')]")).isDisplayed()) {
				iRet = true;
				Reporter.log("Account : "+loggedinAccText+" verified on page.", true) ;
			}else if(this.driver.findElement(By.xpath("//div[@class='error left']")).isDisplayed()){
				// check if error in login credentials message is displayed
				Reporter.log("Incorect login details entered.", true);
				iRet = false;
			}
		} catch (Exception e) {
			Reporter.log("verifyLoginSuccess - failure "+e.getMessage(), true);
			iRet = false;
		}
		
		return iRet;
	}
}

package com.testassignment.pages;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;

import com.testassignment.utility.Helper;

public class TestInsuranceCompany {
	
	WebDriver driver;
	
	public TestInsuranceCompany(WebDriver pdriver){
		this.driver=pdriver;
	}
	
	@FindBy(xpath="//div[@id='scroller']//main//div//nav//div//button[contains(text(),'Write a Review')]") WebElement writeReviewBtn;
	@FindBy(xpath="//input[@type='text' and @name='em']") WebElement inputEmail;
	@FindBy(xpath="//input[@type='password' and @name='pw1']") WebElement inputPwd;
	@FindBy(xpath="//button[@class='btn blue touch-element-cl']") WebElement loginBtn;
	@FindBy(xpath="//span[contains(normalize-space(),'Select')]") WebElement policyTypeDropdown;
	@FindBy(xpath="//div[@role='dialog']//write-review//div//ng-dropdown//div//ul[@role='listbox']//li[@role='option']") List<WebElement> policyTypeSubItemsList;
	@FindBy(xpath="//div[@role='dialog']//write-review//div//ng-dropdown//div//span[@role='button']") WebElement policyReviewTypeBtn;
	@FindBy(xpath="//textarea[@class='textarea wrev-user-input validate']") WebElement reviewTextArea;
	@FindBy(xpath="//div[@class='sbn-action semi-bold-font btn fixed-w-c tall']") WebElement reviewSubmitBtn;
	@FindBy(xpath="//h4[normalize-space()='Your review has been posted.']") WebElement reviewPostSuccess;

	public boolean doOperation(String taskName) {
		
		Reporter.log("Select task on wallethub account", true);
		
		boolean iRet = true;
		
		if(taskName.equals("Write a Review")) {
			writeReviewBtn.click();	
		}else {
			iRet = false;
		}
		
		return iRet;
		// ELSE condition to add other tasks on the home page
	}
	
	public boolean rateReview(int noOfStars) {
		
		Reporter.log("Rate Policy review on page", true); 
		
		boolean iRet = true;
		
		//define required variables 
		Integer iterator = 1;
		
		// Instantiating the action method
		Actions action = new Actions(driver);
		
		//click the star ratings - hover over them one by one and click on the 4th and subsequently on the 5th star
		//get all the star elements for review
		List<WebElement> objArrRatingsStars =  Helper.waitAndReturnElementsListBasedOnCSSSelector("#reviews-section > modal-dialog > div > div > write-review > review-star > div > svg", driver, 20);
				
		if (Helper.verifyCollectionListSize(objArrRatingsStars, 5)) {
			//System.out.println("Number of star ratings visible on review page checkpoint done - elements " + objArrRatingsStars.size() + "."); // report statement
			
			for (WebElement e : objArrRatingsStars) {
				
				try {
					
					//objReviewCatergoryDropList.wait(3000); // current object is woken after 3 seconds just to produce enough seperation while hovering on it 
					Thread.sleep(2000);
					//System.out.println("3 sec wait performed.");
					action.moveToElement(e).build().perform();  // hover on the current runtime element
					
					if (iterator.equals(noOfStars)) { // perform click only on 4th and 5th star
						action.moveToElement(e).click(e).build().perform(); 
						Reporter.log("User star rating - " + iterator + " clicked.", true);
						break;
					}
				} catch (Exception e2) {
					iRet = false;
					Reporter.log("Runtime exception occured : "+e2.getMessage(), true);
				}
				iterator = iterator + 1;  // increment iterator
			}
		}else {
			iRet = false;
			
		}
			
		return iRet;
		
	}

	
	public boolean postReview(String reviewPolicyType, String reviewText) {
		
		Reporter.log("Post Policy review on page", true); 
		
		boolean iRet = true;
		
		try {
			
			// enter the policy rating drop down
			//assert for the policy category drop down 
			
			if (Helper.waitForElementToBeDisplayed(policyTypeDropdown , driver, 10)) {
				policyTypeDropdown.click();
				
				if (Helper.verifyCollectionListSize(policyTypeSubItemsList, 3)) {	
					
					for (WebElement e : policyTypeSubItemsList) {
						
						if (e.getText().equals(reviewPolicyType)) {
							e.click(); // check condition then click
							Reporter.log("Policy rating category is set to - Health Insurance", true);
							break;
						}
					}
					
					// check value added correctly
					if(Helper.verifyElementText(policyReviewTypeBtn, driver, reviewPolicyType)) {
						Reporter.log("Policy rating category verified to be set as - " + reviewPolicyType , true);
						
						if (Helper.waitForElementToBeDisplayed(reviewTextArea , driver, 5)) {
							
							if (reviewText.length() > 200) {
								reviewTextArea.sendKeys(reviewText);
							}else {
								iRet =false;
								Reporter.log("Policy review text content has to be minimum 200 characters, review post hence cannot be done.", true);
							}

						}else {
							iRet =false;
						}
						
					}else {
						iRet =false;
					}
	
				}else {
					iRet = false;
				}
					
				if(iRet) {
					
					if(Helper.verifyElementText(reviewTextArea, driver, reviewText)) {
						//submit review comments
						reviewSubmitBtn.click();
						
						Helper.waitForElementToBeDisplayed(reviewPostSuccess, driver, 10);
						
						Helper.clickDivElementbyText("Continue", driver);
						
					}else {
						iRet = false;
						Reporter.log("Policy review text not input succesfully.", true);
					}
					
				}
			
			}
				
		} catch (Exception e) {
			Reporter.log("Runtime exception occured : "+e.getMessage(), true);
			iRet = false;
		}
		
		return iRet;
	}
	
	
	public boolean verifyReview(String postDescription) {
		
		Reporter.log("Verify Policy review on page", true); 
		
		WebElement editPostLink;
		boolean iRet = true;
			
		try {
			
		    // verify the review feed, scroll to comments area
			editPostLink = Helper.waitAndReturnElementBasedOnCSSSelector("#reviews-section .rvtab-citem .blue-transparent", driver, 10);
			
			// JS call to scroll down to object
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", editPostLink); // scroll down to the edit reviews section
				
			//find and verify your post
			List<WebElement> postsCollection = Helper.waitAndReturnElementsListBasedOnCSSSelector("//div[@class='rvtab-ci-content with-links text-select']", driver, 10);
			
			if(postsCollection.size() >= 1) {
				
				boolean blnArticleFound = false;

				for (WebElement e : postsCollection) // LOOP through each Article and check text
				{
					if (e.getText().equals(postDescription)) { // if text matches the expected text available with us.
						blnArticleFound = true;
						break;
					}
				}
				
				// validate if review feed found on page.	
				if (blnArticleFound) {
					Reporter.log("User's review text verified succesfully on the overall comments page.", true);
				} else {
					Reporter.log("User's review text not verified unlike expected on the overall comments page.", true);
					iRet = false;
				}
			}else {
				Reporter.log("Number of Posts to be verified on page is "+ postsCollection.size()+" .Runtime object collection error occured!", true);
				iRet = false;
			}	
			
		} catch (Exception e) {
			Reporter.log("Runtime exception occured : "+e.getMessage(), true);
			iRet = false;
		}			

		return iRet;
	}

}
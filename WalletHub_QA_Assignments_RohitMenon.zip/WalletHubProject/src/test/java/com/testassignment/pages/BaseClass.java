package com.testassignment.pages;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.testassignment.utility.BrowserFactory;
import com.testassignment.utility.ConfigDataProvider;
import com.testassignment.utility.ExcelDataProvider;
import com.testassignment.utility.Helper;

public class BaseClass {
	
	public WebDriver driver;
	public ExcelDataProvider excel;
	public ConfigDataProvider config;
	public ExtentReports report;
	public ExtentTest logger;

	
	//@BeforeSuite
	@BeforeClass
	public void preSetup1() {
		
		Reporter.log("Setting up the Test Suite - Data Providers, Config providers, runtime Report html", true);
		try {
			excel=new ExcelDataProvider();
			config=new ConfigDataProvider();
			ExtentSparkReporter extent = new ExtentSparkReporter(new File(System.getProperty("user.dir")+"/Reports/TestResults_"+Helper.getCurrentDateTime()+".html"));
			report= new ExtentReports();
			report.attachReporter(extent);
		} catch (Exception e) {
			Reporter.log("Runtime Exception occured : "+e.getMessage(), true);
		}
	}	
	
	@Parameters({"launch_url"})
	@BeforeClass(dependsOnMethods = "preSetup1")
	public void preSetup2(String launch_url) {
		
		try {
			Reporter.log("Setting up Browser and Launching URL", true);
			driver=BrowserFactory.startApplication(driver,config.getBrowser(),config.getDataFromConfig(launch_url));
		} catch (Exception e) {
			Reporter.log("Runtime Exception occured : "+e.getMessage(), true);
		}
	}
	
	@AfterClass
	public void tearDown() {
		
		Reporter.log("Quitting up browser session", true);
		BrowserFactory.quitBrowser(driver);	
	}

	@AfterMethod
	public void tearDownMethod(ITestResult result) {
		
		Reporter.log("Post Test Tear Down procedure initiated", true);
		
		if(result.getStatus()==ITestResult.FAILURE){
			logger.fail("Test failed", MediaEntityBuilder.createScreenCaptureFromPath(Helper.capturescreenshot(driver)).build());
			
		}else if(result.getStatus()==ITestResult.SUCCESS) {
			logger.pass("Test Passed", MediaEntityBuilder.createScreenCaptureFromPath(Helper.capturescreenshot(driver)).build());
			
		}
		report.flush();	
			
	}
}
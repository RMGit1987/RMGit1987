package com.testassignment.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;
import com.testassignment.utility.Helper;

public class LoginFacebook {
	
	WebDriver driver;
	
	public LoginFacebook(WebDriver pdriver){
		this.driver=pdriver;
	}
	
	@FindBy(id="email") WebElement uname;
	
	@FindBy(id="pass") WebElement pwd;
	
	@FindBy(name="login") WebElement loginBtn;
	
	@FindBy(xpath="//div[@aria-label='Create a post']") WebElement myPostSection;	
	
	public boolean loginToFbHomePage(String unameApplication, String pwdApplication) {
		
		Reporter.log("Login to Facebook Web Site", true);
		boolean iRet = true;
		
		try {
			Thread.sleep(2000);
			
			uname.sendKeys(unameApplication);
			pwd.sendKeys(pwdApplication);
			loginBtn.click();
		
			if (Helper.waitForElementToBeDisplayed(myPostSection , driver, 25)) {
				iRet=true;
			}else {
				iRet=false;
			}
				
		} catch (InterruptedException e) {
			Reporter.log("loginToFbHomePage failure "+e.getMessage(), true);
			iRet=false;
		}
		
		return iRet;	
	}

}

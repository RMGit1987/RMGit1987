package com.testassignment.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Reporter;

import com.testassignment.utility.Helper;

public class HomePageActions {
	
	WebDriver driver;
	
	public HomePageActions(WebDriver pdriver){
		this.driver=pdriver;
	}

	@FindBy(xpath="//span[contains(normalize-space(),\"What's on your mind\")]") WebElement myPost;
	
	@FindBy(xpath="//div[@aria-label=\"What's on your mind, Rohit?\"]") WebElement myPostArea;
	
	@FindBy(xpath="//span[contains(text(),'Post')]") WebElement myPostSubmit;
	
	@FindBy(xpath="//span[contains(text(),'Create post')]") WebElement myPostVerify;
	
	
	public boolean writeFBPost(String sMessage) {
		
		Reporter.log("Writing a post to Facebook Web Site", true);
		
		boolean iRet = true;
		boolean isCheckpointSyncDone = false;
		
		try {
			
			myPost.click();
			
			if (Helper.waitForElementToBeDisplayed(myPostArea , driver, 25)) {
				myPostArea.click();
				myPostArea.sendKeys(sMessage);
				myPostSubmit.click();
				
				//wait until the post is submitted successfully
				do {
					if(!Helper.waitForElementToBeDisplayed(myPostVerify , driver, 2)){
						isCheckpointSyncDone = true;
					}
							
				}while(!isCheckpointSyncDone);
				
				if(!isCheckpointSyncDone) {
					iRet=false;
				}
					
			}else {
				iRet=false;
			}
			
		} catch (Exception e) {
			Reporter.log("Writing a post to Facebook Web Site failed "+e.getMessage(), true);
			iRet = false;
		}
		
		return iRet;
		
	}


	public boolean verifyPostExistence(String postText) {
		
		Reporter.log("Verifying a post on Facebook Web Site", true);
		
		boolean iRet = true;
		
		if(this.driver.findElement(By.xpath("//div[contains(text(),'"+postText+"')]")).isDisplayed()) {
			iRet = true;
			Reporter.log("Post : "+postText+" verified on page.", true);
		}else {
			iRet = false;
		}
		
		return iRet;
		
	}
}

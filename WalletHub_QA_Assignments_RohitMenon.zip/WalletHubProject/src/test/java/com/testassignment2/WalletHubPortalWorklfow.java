package com.testassignment2;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.support.PageFactory;

import com.testassignment.pages.BaseClass;
import com.testassignment.pages.LoginWalletHub;
import com.testassignment.pages.TestInsuranceCompany;
import com.testassignment.utility.BrowserFactory;
import com.testassignment.utility.Helper;

public class WalletHubPortalWorklfow extends BaseClass{
	
	boolean blnContinue = true;
	
	@Test
	public void loginWlHub_WritePost() {
		
		String sLoggedInUser = null;
		String sCurrentReviewText = null;
		
		//custom test to report in extent report html file
		logger=report.createTest("Login to WalletHub , write a review and verify posted review.");
		
		//initialize the elements of wallethub login page and Test Insurance Company page which will be used in this method
		LoginWalletHub whApp =PageFactory.initElements(driver, LoginWalletHub.class);
		TestInsuranceCompany reviewPage =  PageFactory.initElements(driver, TestInsuranceCompany.class);
		
		//login to wallethub with the credentials mentioned in data sheet
		sLoggedInUser = whApp.authenticateWithCreds(excel.getStringData("WHubLogin", 0, 0), excel.getStringData("WHubLogin", 0, 1));

		//verify login is success
		if (sLoggedInUser != null) {
			if(whApp.verifyLoginSuccess(sLoggedInUser)) {
				logger.pass("Logged in succesfully to walletHub web site.");

			}else {
				logger.fail("Logged in failure to walletHub web site.");
				blnContinue = false;
			}	
		}else {
			logger.fail("Error while Logging to walletHub web site.");
			blnContinue = false;
		}
		
		//flow check
		if(blnContinue) {
			//test step 2
			//load the test insurance company url
			BrowserFactory.loadCustomUrl(driver, excel.getStringData("WHubLogin", 1, 0) );
			
			//select write a review button
			if(reviewPage.doOperation("Write a Review")) {
				logger.pass("Successfuly clicked on Write a Review Button");
			}else {
				logger.fail("Could not click on Write a Review Button");
				blnContinue = false;
			}
		}	
		
		//flow check
		if(blnContinue) {
			//test step 3
			//converting double to int to use further
			int starsToSet = (int)(excel.getNumericData("WHubLogin", 2, 0));
			
			// set the stars to the review
			if(reviewPage.rateReview(starsToSet)) {
				logger.pass("Rated no of stars as * " + starsToSet);
				
			}else {
				logger.fail("Test Step failure - Rate review");
				blnContinue = false;
			}
	
		}
		
		//flow check
		if(blnContinue) {
			//test step 4
			//define a custom date timestamp and append to the review text.
			sCurrentReviewText = excel.getStringData("WHubLogin", 4, 0) + Helper.getCurrentDateTime();
			
			//post a review on test_insurance_company page.
			if(reviewPage.postReview(excel.getStringData("WHubLogin", 3, 0), sCurrentReviewText)) {
				logger.pass("Review posted succesfully");
			}else {
				logger.fail("Test Step failure - Post review");
				blnContinue = false;
			}
				
		}
		
		//flow check
		if(blnContinue) {
			//test step 5
			//load the test insurance company url
			BrowserFactory.loadCustomUrl(driver, excel.getStringData("WHubLogin", 1, 0) );
			
			//verify posted review exists on page.
			if(reviewPage.verifyReview(sCurrentReviewText)) {
				logger.pass("Review verified succesfully");
			}else {
				logger.fail("Test Step failure - Verify review");
				blnContinue = false;
			}
			
		}
		
		//check and assert PASS/FAIL status to the entire method based on the global boolean variable 
		assertEquals(true, blnContinue);
	}		
}